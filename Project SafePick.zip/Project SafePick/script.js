// Scroll to a section when a button is clicked
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({
        behavior: 'smooth'
    });
}

// Handle the form submission in the Contact section
document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (name && email && message) {
        alert(`Thank you for contacting us, ${name}! We will respond to your message shortly.`);
        this.reset(); // Reset form fields
    } else {
        alert('Please fill out all the required fields.');
    }
});

// Functionality for viewing the prototype
function viewPrototype() {
    alert('Prototype functionality is not yet implemented.');
}
